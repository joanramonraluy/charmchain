# Changelog

##### [0.1.0] - 01 January 2024

- Initial version
